package com.example.calculator;

// imports relevant packages for app creation
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity
{
// creates EditText, TextView and Button variables
    EditText num1, num2;

    TextView result;
    Button add;
    Button sub;
    Button multiply;
    Button divide;
    Button mod;
    Button percent;

    Button clear;
    Button power;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // assigns variables to corresponding objects
        num1 = findViewById(R.id.number1);
        num2 = findViewById(R.id.number2);
        add = findViewById(R.id.addbutton);
        sub = findViewById(R.id.subtractbutton);
        multiply = findViewById(R.id.multiplybutton);
        divide = findViewById(R.id.dividebutton);
        mod = findViewById(R.id.modbutton);
        percent = findViewById(R.id.percentbutton);
        clear = findViewById(R.id.clearbutton);
        power = findViewById(R.id.powerbutton);
        result = findViewById(R.id.result);

        // creates a listener for when add button is pressed
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in a try statement that examines code for potential errors
                try
                {
                    // converts num1 and num2 text inputs to a string
                    String s1 = num1.getText().toString();
                    String s2 = num2.getText().toString();
                    // converts num1 and num2 strings to doubles
                    double a = Double.parseDouble(s1);
                    double b = Double.parseDouble(s2);
                    // adds num1 and num2
                    double sum = ((a) + (b));
                    // displays the addition result
                    result.setText(" " + sum);
                }

                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                   result.setText("Please enter a valid number");
                }

            }
        }
        );

        // creates a listener for when subtract button is pressed
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in try statement that examines code for potential errors
                try
                {
                    // converts num1 and num2 text inputs to a string
                    String s1 = num1.getText().toString();
                    String s2 = num2.getText().toString();
                    // converts num1 and num2 strings to doubles
                    double a = Double.parseDouble(s1);
                    double b = Double.parseDouble(s2);
                    // subtracts num2 from num1
                    double sub = (a) - (b);
                    // displays the subtraction result
                    result.setText(" " + sub);
                }
                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                    result.setText("Please enter a valid number");
                }
            }
        }
        );

        // creates a listener for when multiply button is pressed
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in try statement that examines code for potential errors
                try
                {
                    // converts num1 and num2 text inputs to a string
                    String s1 = num1.getText().toString();
                    String s2 = num2.getText().toString();
                    // converts num1 and num2 strings to doubles
                    double a = Double.parseDouble(s1);
                    double b = Double.parseDouble(s2);
                    // multiplies num1 and num2
                    double multiply = ((a) * (b));
                    // displays the multiplication result
                    result.setText(" " + multiply);
                }

                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                    result.setText("Please enter a valid number");
                }
            }
        }
        );

        // creates a listener for when divide button is pressed
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in try statement that examines code for potential errors
                try
                {
                    // converts num1 and num2 text inputs to a string
                    String s1 = num1.getText().toString();
                    String s2 = num2.getText().toString();
                    // converts num1 and num2 strings to doubles
                    double a = Double.parseDouble(s1);
                    double b = Double.parseDouble(s2);
                    // if num2 input is 0, an arithmetic exception is explicitly thrown
                    if (b == 0)
                    {
                        throw new ArithmeticException();
                    }
                    // divides num1 by num2 if not being divided by 0
                    double divide = ((a) / (b));
                    // displays the division result
                    result.setText(" " + divide);
                }

                // wraps code in catch statement that handles division by 0 error
                catch (ArithmeticException e)
                {
                    // notifies user that they should not divide by 0
                   result.setText("Cannot divide by 0");
                }

                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                    result.setText("Please enter a valid number");
                }

            }
        }
        );

        // creates a listener for when mod button is pressed
        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in try statement that examines code for potential errors
                try
                {
                    // converts num1 and num2 text inputs to a string
                    String s1 = num1.getText().toString();
                    String s2 = num2.getText().toString();
                    // converts num1 and num2 strings to doubles
                    double a = Double.parseDouble(s1);
                    double b = Double.parseDouble(s2);
                    // calculates remainder of num1 divided by num2
                    double mod = ((a) % (b));
                    // displays the remainder of the division result
                    result.setText(" " + mod);
                }

                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                    result.setText("Please enter a valid number");
                }
            }
        }
        );

        // creates a listener for when percent button is pressed
        percent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in try statement that examines code for potential errors
                try
                {
                    // converts num1 and num2 text inputs to a string
                    String s1 = num1.getText().toString();
                    String s2 = num2.getText().toString();
                    // converts the calculated result to a string
                    String s3 = result.getText().toString();
                    // converts num1 and result strings to doubles
                    double a = Double.parseDouble(s1);
                    double c = Double.parseDouble(s3);
                    // created variable for calculated percent
                    double percentanswer;
                    // divides the current calculated result by 100
                    percentanswer = ((c) / (100));
                    // divides the num1 input by 100 if there is no calculated result
                    if (c == 0.0)
                    {
                        // divides the num1 input by 100
                        percentanswer = ((a) / (100));
                    }
                    // displays the current percent of either the first input or calculated result
                    result.setText(" " + percentanswer);
                }

                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                    result.setText("Please enter a valid number");
                }
            }
        }
        );

        // creates a listener for when clear button is pressed
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in try statement that examines code for potential errors
                try
                {
                    // sets the text for num1 and num2 input back to the default text message
                    num1.setText("Enter number 1");
                    num2.setText("Enter number 2");
                    // sets the calculated result back to default value of 0.0
                    double defaultresult = 0.0;
                    // displays the default calculated result
                    result.setText(" " + defaultresult);
                }
                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                    result.setText("Please enter a valid number");
                }
            }
        }
        );

        // creates a listener for when power button is pressed
        power.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // wraps code in try statement that examines code for potential errors
                try
                {
                    // converts num1 and num2 text inputs to a string
                    String s1 = num1.getText().toString();
                    String s2 = num2.getText().toString();
                    // converts num1 and num2 strings to doubles
                    double a = Double.parseDouble(s1);
                    double b = Double.parseDouble(s2);
                    // calculates num1 raised to the power of num2
                    double power = Math.pow((a), (b));
                    // displays the calculated exponential value
                    result.setText(" " + power);
                }
                // wraps code in catch statement that handles incorrect input type errors
                catch (NumberFormatException e)
                {
                    // notifies user to input a number when a string cannot be converted to a double
                    result.setText("Please enter a valid number");
                }

            }
        }
        );

    }
}